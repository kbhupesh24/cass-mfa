package com.att.cassandra.security.auth.ldap;

import org.junit.jupiter.api.Disabled;

@Disabled("Merged into LdapServiceTest")
public class LdapServiceUnitTest {
    // Tests have been consolidated into LdapServiceTest.java
}
