package com.att.cassandra.security.auth.ldap;

import org.junit.jupiter.api.Disabled;

@Disabled("Removed unstable cache tests")
public class LdapServiceCacheTest {
    // No tests
}
